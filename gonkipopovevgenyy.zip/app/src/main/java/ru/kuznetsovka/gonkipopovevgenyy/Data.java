package ru.kuznetsovka.gonkipopovevgenyy;

public class Data {
    public static String playerName = "Player";
}
